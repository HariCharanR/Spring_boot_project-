import React from 'react'

function CustomerForm() {
  return (
    <div>CustomerForm</div>
  )
}

export default CustomerForm