import React from 'react'

function Customers() {
  return (
    <div>Customers</div>
  )
}

export default Customers